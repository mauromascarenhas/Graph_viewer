#ifndef MODEL_H
#define MODEL_H

#include <QtOpenGL>
#include <QOpenGLWidget>
#include <QOpenGLExtraFunctions>
#include <QTextStream>
#include <QFile>

#include <fstream>
#include <limits>
#include <iostream>

class Model : public QOpenGLExtraFunctions
{
public:
    explicit Model(QOpenGLWidget *widget = nullptr);
    ~Model();

    void readOFFFIle(const QString &fileName);
    void drawModel();

    inline uint countFaces(){ return this->facesCount; }
    inline uint countVertexes(){ return this->vertexCount; }

    inline QVector3D& getMidPoint() { return this->midPoint; }
    inline QMatrix4x4& getModelMatrix(){ return this->modelMatrix; }

private:
    double invDiag;
    QVector3D midPoint;
    QMatrix4x4 modelMatrix;

    uint *indexes;
    QVector4D *vertexes;

    QOpenGLWidget *glWidget;

    uint facesCount;
    uint vertexCount;

    GLuint vao;

    GLuint vboIndexes;
    GLuint vboVertexes;

    GLuint shaderProgram;

    void createVBOs();
    void createShaders();

    void destroyVBOs();
    void destroyShaders();
};

#endif // MODEL_H
