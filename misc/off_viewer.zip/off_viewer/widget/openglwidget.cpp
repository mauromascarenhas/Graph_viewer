#include "openglwidget.h"

OpenGLWidget::OpenGLWidget(QWidget *parent) : QOpenGLWidget(parent)
{
    model = nullptr;
}

OpenGLWidget::~OpenGLWidget(){
    if (model){
        delete model;
        model = nullptr;
    }
}

void OpenGLWidget::showOpenFileDialog(){
    QString fName = QFileDialog::getOpenFileName(nullptr, "Open file",
                                                 QDir::homePath(), QString("OFF File (*.off)"), nullptr
#ifdef __unix__
                                                 , QFileDialog::DontUseNativeDialog
#endif
                                                 );
    if (!fName.isEmpty()){
        model = new Model(this);
        model->readOFFFIle(fName);
        emit statusBarMessage(QString("Vertexes: %1, Faces: %2").arg(model->countVertexes()).arg(model->countFaces()), 0);
    }
    update();
}

void OpenGLWidget::initializeGL(){
    initializeOpenGLFunctions();

    qDebug ("OpenGL version : %s", glGetString ( GL_VERSION ));
    qDebug ("GLSL %s", glGetString ( GL_SHADING_LANGUAGE_VERSION ));

    glEnable(GL_DEPTH_TEST);
}

void OpenGLWidget::resizeGL(int w, int h){
    glViewport(0, 0, w, h);
}

void OpenGLWidget::paintGL(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (!model) return;
    model->drawModel();
}
