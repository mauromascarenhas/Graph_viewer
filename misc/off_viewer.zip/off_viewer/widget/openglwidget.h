#ifndef OPENGLWIDGET_H
#define OPENGLWIDGET_H

#include <QtOpenGL>
#include <QOpenGLWidget>
#include <QOpenGLExtraFunctions>

#include "model.h"

class OpenGLWidget : public QOpenGLWidget, protected QOpenGLExtraFunctions
{
    Q_OBJECT
public:
    explicit OpenGLWidget(QWidget *parent = nullptr);
    ~OpenGLWidget();

public slots:
    void showOpenFileDialog();

private:
    Model *model;

protected:
    void initializeGL();
    void resizeGL(int w, int h);
    void paintGL();

signals:
    void statusBarMessage(const QString &msg, int timeout);
};

#endif // OPENGLWIDGET_H
